# Complete .EXE Build Instructions

## For Windows PC Only

---

## ⚠️ Important Notes

1. **Cannot build on Replit/Linux** - Must use Windows PC
2. **First time takes 20-25 minutes** - This is normal
3. **Requires Python with PATH** - Critical for SQLite compilation
4. **Visual Studio Build Tools required** - For native modules

---

## Step-by-Step Guide

### 1. Install Prerequisites

#### A. Node.js (Required)

**Download:** https://nodejs.org/  
**Version:** LTS (currently v20+)

**Installation:**
1. Download Windows Installer (.msi)
2. Run installer
3. Accept all defaults
4. Click "Install"
5. Wait for completion
6. Click "Finish"

**Verify:**
```cmd
node --version
npm --version
```

---

#### B. Python (Required for SQLite)

**Download:** https://www.python.org/downloads/  
**Version:** 3.10, 3.11, or 3.12

**Installation:**
1. Download Windows Installer
2. Run installer
3. ✅ **CHECK "Add Python to PATH"** ← CRITICAL!
4. Click "Install Now"
5. Wait for completion
6. Click "Close"

**Verify (NEW Command Prompt):**
```cmd
python --version
```

Should show: `Python 3.x.x`

**If not found:**
- Reinstall Python
- Make sure to check "Add Python to PATH"
- Open NEW Command Prompt

---

#### C. Visual Studio Build Tools (Required for Native Modules)

**Download:** https://visualstudio.microsoft.com/downloads/  
**Scroll to:** "Tools for Visual Studio"  
**Download:** "Build Tools for Visual Studio 2022"

**Installation:**
1. Run installer
2. Select workload: **"Desktop development with C++"**
3. Ensure these are checked:
   - ✅ MSVC v143 - VS 2022 C++ build tools
   - ✅ Windows 10/11 SDK
   - ✅ C++ CMake tools for Windows
4. Click "Install"
5. Wait (~3-5 GB download)
6. Restart computer

---

### 2. Extract Build Package

**File:** `final-exe-package.tar.gz` or `final-exe-package.zip`

**Extraction:**
1. Use 7-Zip (recommended) or WinRAR
2. Extract to: `C:\AMPaints-Build\`
3. Result:
   ```
   C:\AMPaints-Build\
   ├── package.json
   ├── build-electron.js
   ├── client/
   ├── server/
   ├── electron/
   └── ... (other files)
   ```

---

### 3. Install Dependencies

**Open Command Prompt:**

```cmd
# Navigate to project
cd C:\AMPaints-Build

# Install all dependencies
npm install
```

**Wait:** 5-10 minutes

**What happens:**
- Downloads ~300 MB of packages
- Compiles better-sqlite3 (needs Python)
- Compiles bufferutil (optional, needs VS Build Tools)
- Sets up all dependencies

**Expected output:**
```
added 500+ packages in 5m
```

**If errors:**
- Check Python is in PATH: `python --version`
- Check VS Build Tools installed
- See Troubleshooting section below

---

### 4. Build .EXE Installer

**Command:**
```cmd
npm run electron:dist
```

**Wait:** 10-15 minutes (first time)

**What happens:**
1. Compiles Electron TypeScript files → CommonJS
2. Builds React frontend with Vite
3. Bundles Express.js server
4. Downloads Electron binaries (~120 MB)
5. Packages everything together
6. Creates NSIS installer

**Expected output:**
```
✔ Electron files compiled successfully!
✔ Building entry: dist-electron/main.cjs
✔ Building NSIS target
✔ Building block map
✔ Application packaged successfully!

Output files:
  release\AMPaints-PaintPulse-Setup-1.0.0.exe (200 MB)
```

---

### 5. Verify Build

**Check release folder:**
```
C:\AMPaints-Build\release\
├── AMPaints-PaintPulse-Setup-1.0.0.exe    ← Installer
├── win-unpacked\                           ← Unpacked files
└── builder-debug.yml                       ← Build info
```

**Test installer:**
1. Double-click `AMPaints-PaintPulse-Setup-1.0.0.exe`
2. Installation wizard should open
3. Choose installation directory
4. Complete installation
5. Launch application
6. Enter activation code: `3620192373285`
7. Application should work!

---

## Alternative Builds

### Portable Version (No Installation)

**Command:**
```cmd
npm run electron:dist:portable
```

**Output:**
```
release\AMPaints-PaintPulse-Portable-1.0.0.exe
```

**Usage:**
- Single .exe file
- No installation required
- Run from anywhere (USB drive, etc.)
- Database saved in app folder

---

### Both Installer + Portable

**Command:**
```cmd
npm run electron:dist:all
```

**Output:**
- AMPaints-PaintPulse-Setup-1.0.0.exe (Installer)
- AMPaints-PaintPulse-Portable-1.0.0.exe (Portable)

---

## Troubleshooting

### Python Not Found

**Error:**
```
Error: Could not find any Python installation to use
```

**Solution:**
1. Install Python from python.org
2. ✅ Check "Add Python to PATH" during installation
3. **Close all Command Prompts**
4. **Open NEW Command Prompt**
5. Verify: `python --version`
6. If still not found:
   - Manual PATH setup (see Advanced section)
   - Or reinstall Python

---

### Visual Studio Build Tools Missing

**Error:**
```
error MSB8036: The Windows SDK version was not found
```

**Solution:**
1. Install Visual Studio Build Tools 2022
2. Select "Desktop development with C++"
3. Install
4. Restart computer
5. Try build again

---

### better-sqlite3 Compilation Failed

**Error:**
```
node-gyp failed to rebuild 'better-sqlite3'
```

**Solution:**
```cmd
# Clean rebuild
rmdir /s /q node_modules
del package-lock.json

# Reinstall
npm install

# Force rebuild better-sqlite3
npm install --build-from-source better-sqlite3

# Try build again
npm run electron:dist
```

---

### electron-builder Fails

**Error:**
```
Cannot find module 'electron'
```

**Cause:** electron is in devDependencies (correct!)

**Solution:**
```cmd
# Clean install
rmdir /s /q node_modules
del package-lock.json
npm install

# Verify electron installed
npm list electron

# Should show: electron@38.4.0 (devDependencies)

# Build
npm run electron:dist
```

---

### Build Takes Too Long

**First build:** 20-25 minutes is NORMAL

**Why:**
- Downloads Electron runtime (~120 MB)
- Compiles native modules (SQLite, bufferutil)
- Bundles all dependencies
- Creates installer

**Next builds:** 2-3 minutes only (cached)

**Speed up:**
- Use SSD (not HDD)
- Close other programs
- Disable antivirus temporarily

---

### Disk Space Issues

**Error:**
```
ENOSPC: no space left on device
```

**Required space:**
- node_modules: ~500 MB
- Build output: ~300 MB
- Installer: ~200 MB
- **Total:** ~1 GB free space needed

**Solution:**
- Free up disk space
- Use different drive
- Clean npm cache: `npm cache clean --force`

---

## Advanced: Manual Python PATH Setup

**If Python installed but not in PATH:**

### 1. Find Python Location

Usually one of:
```
C:\Users\[Username]\AppData\Local\Programs\Python\Python312\
C:\Program Files\Python312\
C:\Python312\
```

### 2. Add to PATH

1. Windows Search → "Environment Variables"
2. Click "Edit the system environment variables"
3. Click "Environment Variables..."
4. Under "User variables" → Select "Path" → Click "Edit..."
5. Click "New"
6. Add Python paths:
   ```
   C:\Users\[Username]\AppData\Local\Programs\Python\Python312\
   C:\Users\[Username]\AppData\Local\Programs\Python\Python312\Scripts\
   ```
7. Click OK (3 times)
8. **Close all Command Prompts**
9. **Open NEW Command Prompt**
10. Verify: `python --version`

---

## Distribution Checklist

After successful build:

- [ ] Test installer on clean Windows PC
- [ ] Verify activation code works: `3620192373285`
- [ ] Test all features (products, sales, database)
- [ ] Test database export/import
- [ ] Upload installer to cloud storage
- [ ] Share download link + activation code
- [ ] Provide user instructions

---

## Build Commands Reference

```cmd
# Install dependencies
npm install

# Build installer (NSIS)
npm run electron:dist

# Build portable .exe
npm run electron:dist:portable

# Build both
npm run electron:dist:all

# Clean rebuild
rmdir /s /q node_modules
del package-lock.json
npm install
npm run electron:dist
```

---

## File Sizes

**node_modules:** ~500 MB  
**Build output:** ~300 MB  
**Final installer:** ~200 MB  
**Installed application:** ~250 MB  
**Database:** Grows with usage (typically 5-50 MB)

---

## Build Time Breakdown

| Step | First Time | Subsequent |
|------|-----------|-----------|
| npm install | 5-10 min | 2-3 min |
| Compile Electron | 1 min | 30 sec |
| Build frontend | 2 min | 1 min |
| Build backend | 30 sec | 20 sec |
| Download Electron | 5 min | 0 (cached) |
| Create installer | 3-5 min | 2 min |
| **Total** | **20-25 min** | **5-7 min** |

---

## Success Indicators

**Installation successful:**
```
npm install
...
added 500+ packages
```

**Build successful:**
```
npm run electron:dist
...
✔ Electron files compiled successfully!
✔ Building NSIS target
✔ Application packaged successfully!
```

**File created:**
```
release\AMPaints-PaintPulse-Setup-1.0.0.exe
```

**Installer works:**
- Double-click → Wizard opens
- Install → Success
- Launch → Activation screen
- Enter code → Application loads

---

**Activation Code:** `3620192373285`

---

**Ready to distribute!** 🚀
