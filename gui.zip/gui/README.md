# AMPaints - PaintPulse Desktop Application

## Professional Paint Store Management System

**Version:** 1.0.0  
**Platform:** Windows (64-bit)  
**Database:** SQLite (Offline)  
**Activation Code:** `3620192373285`

---

## Features

✅ **Complete Offline Operation** - No internet required  
✅ **SQLite Database** - User-selectable location for easy backup  
✅ **Activation System** - One-time activation with permanent license  
✅ **Professional Installer** - NSIS-based Windows installer  
✅ **Product Management** - Full inventory control with colors and variants  
✅ **Sales & Billing** - POS system with payment tracking  
✅ **Stock Management** - Real-time inventory updates  
✅ **Database Export/Import** - Easy backup and restore  

---

## System Requirements

**Operating System:**
- Windows 7 / 8 / 10 / 11 (64-bit)

**Hardware:**
- RAM: 4 GB minimum (8 GB recommended)
- Disk Space: 500 MB for application + database storage
- Processor: Dual-core 2.0 GHz or better

**For Building .EXE:**
- Node.js v20+ (LTS)
- Python 3.10+ (with PATH)
- Visual Studio Build Tools 2022

---

## Building the .EXE Installer

### Prerequisites

1. **Node.js**
   - Download: https://nodejs.org/
   - Version: LTS (v20+)
   - Install with default settings

2. **Python**
   - Download: https://www.python.org/
   - Version: 3.10 or later
   - **IMPORTANT:** Check "Add Python to PATH" during installation

3. **Visual Studio Build Tools**
   - Download: https://visualstudio.microsoft.com/downloads/
   - Select: "Build Tools for Visual Studio 2022"
   - Install components:
     - ✅ Desktop development with C++
     - ✅ Windows 10/11 SDK

### Build Steps

```cmd
# 1. Navigate to project directory
cd path\to\final-exe-package

# 2. Install dependencies (first time only)
npm install

# 3. Build the .EXE installer
npm run electron:dist
```

**Build Time:**
- First install: 5-10 minutes
- Build process: 10-15 minutes
- Total: ~20-25 minutes

**Output:**
```
release\AMPaints-PaintPulse-Setup-1.0.0.exe  (~200 MB)
```

---

## Alternative Build Commands

### Portable Version (No Installation Required)
```cmd
npm run electron:dist:portable
```
Output: `AMPaints-PaintPulse-Portable-1.0.0.exe`

### Both Installer + Portable
```cmd
npm run electron:dist:all
```

---

## Installation (End Users)

1. Download `AMPaints-PaintPulse-Setup-1.0.0.exe`
2. Double-click to run installer
3. Follow installation wizard
4. Choose installation directory
5. Complete installation
6. Launch AMPaints - PaintPulse
7. Enter activation code: `3620192373285`
8. Start managing your paint store!

---

## Activation

**Activation Code:** `3620192373285`

- One-time entry required
- Permanent activation (stored locally)
- No internet connection needed
- Code is stored securely in user settings

---

## Database Management

### Default Location
```
C:\Users\[Username]\Documents\PaintPulse\paintpulse.db
```

### Change Database Location
- Settings → Change Database Location
- Select new folder and filename
- Application will restart with new database

### Backup Database
- Settings → Export Database
- Choose backup location
- Creates copy of database file

### Restore Database
- Settings → Import Database
- Select backup file
- Application will restart with restored data

---

## Project Structure

```
final-exe-package/
├── package.json              # Dependencies and build config
├── build-electron.js         # Electron compilation script
├── LICENSE.txt               # MIT License
├── client/                   # Frontend React application
├── server/                   # Express.js backend
├── electron/                 # Electron main and preload scripts
│   ├── main.ts              # Main process (window, IPC)
│   └── preload.ts           # Preload script (context bridge)
├── dist-electron/           # Compiled Electron files
│   ├── main.cjs             # Compiled main process
│   └── preload.cjs          # Compiled preload script
├── shared/                  # Shared types and schemas
├── vite.config.ts           # Vite bundler configuration
├── tsconfig.json            # TypeScript configuration
├── tailwind.config.ts       # Tailwind CSS configuration
└── drizzle.config.ts        # Drizzle ORM configuration
```

---

## Technology Stack

**Frontend:**
- React 18
- TypeScript
- Tailwind CSS
- shadcn/ui components
- TanStack Query (React Query)
- Wouter (routing)

**Backend:**
- Express.js
- SQLite3 (better-sqlite3)
- Drizzle ORM

**Desktop:**
- Electron 38
- electron-store (settings persistence)
- electron-builder (packaging)

---

## Troubleshooting

### Error: "Python not found"

**Solution:**
1. Install Python from https://www.python.org/
2. **IMPORTANT:** Check "Add Python to PATH" checkbox
3. Restart Command Prompt
4. Verify: `python --version`
5. Run `npm install` again

### Error: "better-sqlite3 build failed"

**Solution:**
1. Install Visual Studio Build Tools 2022
2. Ensure "Desktop development with C++" is selected
3. Run:
   ```cmd
   npm install --build-from-source better-sqlite3
   npm run electron:dist
   ```

### Error: "electron-builder failed"

**Solution:**
1. Delete `node_modules` and `package-lock.json`
2. Clean install:
   ```cmd
   rmdir /s /q node_modules
   del package-lock.json
   npm install
   npm run electron:dist
   ```

### Build is very slow

**Normal!** First build downloads:
- Electron (~120 MB)
- Compiles native modules (SQLite)
- Bundles all dependencies
- Creates installer

Subsequent builds: 2-3 minutes only

---

## Distribution

**Share with users:**

1. **Upload installer** to:
   - Google Drive
   - Dropbox
   - OneDrive
   - WeTransfer
   - USB drive

2. **Provide activation code:** `3620192373285`

3. **Share instructions:**
   - Install application
   - Enter activation code
   - Start using!

---

## Support

For issues or questions:
- Check README.md (this file)
- Review BUILD_INSTRUCTIONS.md
- Check EXE_BANANE_KA_TAREEQA.md (Urdu guide)

---

## License

MIT License - See LICENSE.txt

---

## Version History

**1.0.0** (2025)
- Initial release
- SQLite database with user-selectable location
- Activation code system
- Professional NSIS installer
- Complete offline operation
- Database export/import functionality

---

**Built with ❤️ for AMPaints**
