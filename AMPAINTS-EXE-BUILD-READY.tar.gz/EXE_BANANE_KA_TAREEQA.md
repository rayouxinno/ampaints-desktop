# .EXE Installer Banane Ka Complete Tareeqa

## **AMPaints - PaintPulse Desktop Application**

**Activation Code:** `3620192373285`

---

## ⚠️ **Zaroori Batein**

1. **Replit/Linux pe nahi ban sakta** - Sirf Windows PC pe hi build hoga
2. **Pehli baar 20-25 minute lagenge** - Yeh normal hai
3. **Python zaroori hai (with PATH)** - SQLite compile karne ke liye
4. **Visual Studio Build Tools chahiye** - Native modules ke liye

---

## 📋 **Complete Step-by-Step Guide**

### **Step 1: Software Install Karein (Windows PC)**

#### **A. Node.js (Zaroori)**

**Download:** https://nodejs.org/  
**Version:** LTS (latest stable)

**Kaise install karein:**
1. Website se Windows Installer (.msi) download karo
2. Installer run karo
3. Sab defaults accept karo
4. "Install" click karo
5. Installation complete hone ka wait karo
6. "Finish" click karo

**Check karein:**
```cmd
node --version
npm --version
```

Agar version dikhe toh perfect! ✅

---

#### **B. Python (Zaroori - SQLite ke liye)**

**Download:** https://www.python.org/downloads/  
**Version:** 3.10, 3.11, ya 3.12 (koi bhi chalega)

**Installation (IMPORTANT):**
1. Python installer download karo
2. Installer run karo
3. ✅ **"Add Python to PATH" checkbox CHECK KARO!** ← Bahut zaroori!
4. "Install Now" click karo
5. Wait for installation
6. "Close" click karo
7. **Computer restart karo** (optional but recommended)

**Verify karein (NAYA Command Prompt kholo):**
```cmd
python --version
```

**Agar yeh dikhe:**
```
Python 3.12.x
```

**Toh perfect! ✅**

**Agar "python is not recognized" dikhe:**
- Python reinstall karo
- Checkbox ✅ "Add Python to PATH" zaror check karo
- Computer restart karo
- Naya CMD window kholo

---

#### **C. Visual Studio Build Tools (Zaroori)**

**Download:** https://visualstudio.microsoft.com/downloads/  
**Scroll karke dhundo:** "Tools for Visual Studio"  
**Download:** "Build Tools for Visual Studio 2022"

**Installation:**
1. Build Tools installer run karo
2. **"Desktop development with C++"** select karo
3. Yeh sab checked hone chahiye:
   - ✅ MSVC v143 - VS 2022 C++ build tools
   - ✅ Windows 10/11 SDK
   - ✅ C++ CMake tools for Windows
4. "Install" click karo
5. Wait karo (~3-5 GB download hoga)
6. Installation complete hone ke baad **computer restart karo**

---

### **Step 2: Build Package Extract Karein**

**File:** `final-exe-package.tar.gz` ya `final-exe-package.zip`

**Kaise extract karein:**

1. **7-Zip install karo** (agar nahi hai)
   - Download: https://www.7-zip.org/
   - Best for .tar.gz files

2. **Extract karein:**
   - Right-click on `final-exe-package.tar.gz`
   - 7-Zip → Extract Here
   - Agar .tar file bane, usko bhi extract karo
   
3. **Location:**
   ```
   C:\AMPaints-Build\
   ```

4. **Result:**
   ```
   C:\AMPaints-Build\
   ├── package.json
   ├── build-electron.js
   ├── LICENSE.txt
   ├── client/
   ├── server/
   ├── electron/
   ├── dist-electron/
   └── ... (aur files)
   ```

---

### **Step 3: Dependencies Install Karein**

**Command Prompt kholo:**

```cmd
# Project folder mein jao
cd C:\AMPaints-Build

# Sab packages install karo
npm install
```

**Wait:** 5-10 minutes

**Kya hoga:**
- ~300 MB packages download honge
- better-sqlite3 compile hoga (Python use karega)
- bufferutil compile hoga (VS Build Tools use karega)
- Sab dependencies install honge

**Successful output:**
```
added 500+ packages in 5m
```

**Agar error aaye:**
- Python check karo: `python --version`
- VS Build Tools install hai ya nahi
- Neeche Troubleshooting section dekho

---

### **Step 4: .EXE Installer Banao!** 🚀

**Command:**
```cmd
npm run electron:dist
```

**Wait:** 10-15 minutes (pehli baar)

**Kya hoga:**
1. Electron TypeScript files compile hongi
2. React frontend build hoga (Vite se)
3. Express.js server bundle hoga
4. Electron binaries download hongi (~120 MB)
5. Sab kuch package hoga
6. Professional NSIS installer banega

**Successful output:**
```
✔ Electron files compiled successfully!
✔ Building entry: dist-electron/main.cjs
✔ Building NSIS target
✔ Building block map
✔ Application packaged successfully!

Output:
  release\AMPaints-PaintPulse-Setup-1.0.0.exe (200 MB)
```

---

### **Step 5: Installer Test Karein**

**Check folder:**
```
C:\AMPaints-Build\release\
├── AMPaints-PaintPulse-Setup-1.0.0.exe    ← Yeh aapka installer!
└── win-unpacked\                           ← Unpacked files
```

**Test:**
1. `AMPaints-PaintPulse-Setup-1.0.0.exe` pe double-click
2. Installation wizard khulega
3. Installation folder choose karo
4. Install complete karo
5. Application launch karo
6. Activation code dalo: `3620192373285`
7. Application chalne lagega! ✅

---

## 🎯 **Quick Commands Summary**

```cmd
# 1. Project folder mein jao
cd C:\AMPaints-Build

# 2. Dependencies install (pehli baar)
npm install

# 3. Installer banao
npm run electron:dist

# Result: release\AMPaints-PaintPulse-Setup-1.0.0.exe
```

---

## 📦 **Alternative Builds**

### **Portable Version (Installation nahi chahiye)**

**Command:**
```cmd
npm run electron:dist:portable
```

**Output:**
```
AMPaints-PaintPulse-Portable-1.0.0.exe
```

**Faida:**
- Single .exe file
- Installation ki zaroorat nahi
- USB se bhi chala sakte ho
- Kisi bhi folder se run karo

---

### **Dono Banao (Installer + Portable)**

**Command:**
```cmd
npm run electron:dist:all
```

**Output:**
- AMPaints-PaintPulse-Setup-1.0.0.exe (Installer)
- AMPaints-PaintPulse-Portable-1.0.0.exe (Portable)

---

## 🔧 **Problems Aur Solutions**

### **Problem 1: Python Nahi Mil Raha**

**Error:**
```
Error: Could not find any Python installation to use
```

**Solution:**
1. Python install karo: https://www.python.org/
2. ✅ **"Add Python to PATH" checkbox check karo!**
3. Install complete karo
4. **Purane sab CMD windows band karo**
5. **NAYA Command Prompt kholo**
6. Check: `python --version`
7. Agar phir bhi nahi dikha:
   - Computer restart karo
   - Ya Python reinstall karo checkbox ke saath

---

### **Problem 2: Visual Studio Build Tools Missing**

**Error:**
```
error MSB8036: The Windows SDK version was not found
```

**Solution:**
1. VS Build Tools 2022 install karo
2. "Desktop development with C++" select karo
3. Install karo
4. Computer restart karo
5. Dobara build try karo

---

### **Problem 3: better-sqlite3 Compile Nahi Hua**

**Error:**
```
node-gyp failed to rebuild 'better-sqlite3'
```

**Solution:**
```cmd
# Clean install
rmdir /s /q node_modules
del package-lock.json

# Fresh install
npm install

# Force rebuild
npm install --build-from-source better-sqlite3

# Build dobara try karo
npm run electron:dist
```

---

### **Problem 4: Build Bahut Slow Hai**

**Pehli baar:** 20-25 minutes NORMAL hai!

**Kyun itna time:**
- Electron runtime download (~120 MB)
- Native modules compile (SQLite, bufferutil)
- Sab dependencies bundle
- Installer create

**Agli baar:** Sirf 2-3 minutes (cached rahega)

**Fast kaise karein:**
- SSD use karo (HDD nahi)
- Dusre programs band karo
- Antivirus temporarily disable karo

---

### **Problem 5: Disk Space Kam Hai**

**Error:**
```
ENOSPC: no space left on device
```

**Kitni space chahiye:**
- node_modules: ~500 MB
- Build files: ~300 MB
- Final installer: ~200 MB
- **Total:** Kam se kam 1 GB khali space

**Solution:**
- Disk space khali karo
- Dusri drive use karo
- npm cache clean: `npm cache clean --force`

---

## 📤 **Distribution (Users Ko Kaise Dein)**

### **Installer Share Karein:**

**Upload:**
- Google Drive
- Dropbox
- OneDrive
- WeTransfer
- USB drive

**File:** `AMPaints-PaintPulse-Setup-1.0.0.exe` (200 MB)

### **Users Ko Instructions:**

```
1. AMPaints-PaintPulse-Setup-1.0.0.exe download karo
2. Double-click karo
3. Installation wizard follow karo
4. Folder choose karo
5. Install karo
6. Application launch karo
7. Yeh code dalo: 3620192373285
8. Start using! 🎨
```

---

## ⏱️ **Time Breakdown**

| Kaam | Pehli Baar | Agli Baar |
|------|-----------|-----------|
| npm install | 5-10 min | 2-3 min |
| Electron compile | 1 min | 30 sec |
| Frontend build | 2 min | 1 min |
| Backend build | 30 sec | 20 sec |
| Electron download | 5 min | 0 (cached) |
| Installer create | 3-5 min | 2 min |
| **Total** | **20-25 min** | **5-7 min** |

---

## ✅ **Success Ke Signs**

**npm install successful:**
```
added 500+ packages
```

**Build successful:**
```
✔ Electron files compiled successfully!
✔ Building NSIS target
✔ Application packaged successfully!
```

**File ban gayi:**
```
release\AMPaints-PaintPulse-Setup-1.0.0.exe ✅
```

**Installer kaam kar raha:**
- Double-click → Wizard khula
- Install → Success
- Launch → Activation screen dikha
- Code dala → Application load hui

---

## 📝 **Checklist (Distribution Se Pehle)**

Build complete hone ke baad:

- [ ] Clean Windows PC pe test karo
- [ ] Activation code test karo: `3620192373285`
- [ ] Sab features check karo (products, sales, database)
- [ ] Database export/import test karo
- [ ] Cloud storage pe upload karo
- [ ] Download link share karo
- [ ] Activation code + instructions share karo

---

## 🎉 **Summary**

**Total Time:** 30-40 minutes (pehli baar)  
**Requirements:**
- ✅ Windows PC
- ✅ Node.js
- ✅ Python (with PATH)
- ✅ VS Build Tools

**Steps:**
1. Software install karo (Node, Python, VS Tools)
2. Package extract karo
3. `npm install`
4. `npm run electron:dist`
5. Installer mil jayega!

**Output:**
- Professional Windows installer
- ~200 MB size
- Desktop + Start Menu shortcuts
- Uninstaller included
- Offline capable
- SQLite database

---

**Activation Code:** `3620192373285`

**Build karo aur distribute karo!** 🚀✅

---

## 📞 **Aur Help Chahiye?**

**Check karein:**
- README.md (English)
- BUILD_INSTRUCTIONS.md (Detailed English)
- EXE_BANANE_KA_TAREEQA.md (Yeh file - Urdu)

**Common issues:**
- Python PATH issue → Reinstall with checkbox
- VS Build Tools → Full installation karo
- Slow build → Normal hai pehli baar

---

**Successful build ke liye dua hai! Insha'Allah sab perfect hoga!** 🤲✨
